# Vijayakumar Sambandam Resume

Upload this ZIP to Overleaf as a new project. Set the compiler to **XeLaTeX** and select **resume.tex** as the main document. The Source Sans Pro fonts are included. The page break is explicit so the first-page header and the continuation follow the template's multipage layout.

Edit the contact details in `resume.tex` and the resume content under `sections/`. The three-part header is in `_header.tex`; the type, color, and spacing are in `TLCresume.sty`.

## Details to confirm before sharing

- Replace the current Tech Mahindra title and assignment placeholders. Add the scope and a measurable outcome. Confirm whether Offshore Delivery Center Manager was a formal title.
- Fill in the Ford and Mazda role, scope, and outcome placeholders. The profile supplies assignment dates. Confirm the broader service provider engagement's end date or ongoing status. The Japan readiness and remediation work is documented separately for 2021–2022. Verify the product name before adding the 1909 version.
- Clarify what the peak figure of 180 measures, which program it belongs to, and whether it refers to the team he managed directly or the wider program.
- Confirm the 2001–2008 electronics retail title. The profiles use both Supply Chain Lead and Technical Support Manager.
- Check the names and issuers of TechM PMP, SAP, SAFe, and ITIL credentials. Confirm whether TechM PMP is internal or issued by PMI, and whether SAP Workflow, CRM, and BW were training or certifications.
- Confirm the preferred email for recruiters. This draft uses the Tech Mahindra address from his profile.
- Add specific tools or responsibilities from the competency notes where he can substantiate them with an account or outcome. Examples include Waterfall, ServiceNow, Remedy, Jira, Confluence, budgeting and pricing, SLA ownership, vendor management, and risk, escalation, change, or incident management.
- Recompile and review both pages after replacing the bracketed placeholders. Update the page break if the confirmed detail changes the length materially.

## Attribution

Adapted from Timmy Chan's [Data Science Tech Resume Template](https://www.overleaf.com/latex/templates/data-science-tech-resume-template/zcdmpfxrzjhv), distributed under CC BY 4.0. This adaptation replaces the sample content, adjusts the contact header, and bundles [Adobe Source Sans Pro](https://github.com/adobe-fonts/source-sans/tree/2.045R-ro%2F1.095R-it) for XeLaTeX. The template and font licenses are in `LICENSE.txt` and `fonts/LICENSE.txt`.
